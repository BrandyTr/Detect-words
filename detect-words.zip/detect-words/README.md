# Detect-words

### How to run this code
**Step 1:** Open the terminal and run these commands: `cd detect-words`; `npm run dev`<br>
**Step 2:** Download extension **Extensions Reloader**<br>


**Note**: Note: I've modified the code so that when you save the file (Ctrl + S), it will automatically run `npm run build`. Now, you don't need to manually run the build every time. Just <u>save the file</u> and <u>click the **Extensions Reloader**</u>, our extension will update automatically.
