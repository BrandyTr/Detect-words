export default function Header() {
    return (
        <header className="bg-primary-darkBlue font-montserrat font-black text-white text-base text-left px-5 py-2.5 fixed top-0 left-0 right-0 w-full z-1">
            Detect Bad Words
        </header>
    )
}